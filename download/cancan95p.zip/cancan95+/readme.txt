CANCAN95+
--------
Nothing new. It just looks pretty and uses Wordpad to load/edit on
MUME

***********************************************
****** MAKE SURE YOU #IDENTIFY IN MUME ********
***********************************************

CANCAN95
--------

Cancan95 is a MUD client for Windows 95 that runs in a console, which
means it can be zoomed up to full-screen DOS mode using ALT+RETURN. That
is good because the scrolling is very fast then.

Cancan95 is an extension of powwow0.8 which is an extension of an older
version of cancan. Messy right?

Cancan95 DOES NOT WORK ON NT4, at least not as far as I know. The reason for
this is simply that Microsoft has chosen not to support the standard ANSI
cursor positioning and color escape codes in their command prompts. NT4 DOES
support ANSI in DOS programs running in the Command Prompt, but NOT for real
Win32 Console programs like Cancan95. The workaround is to replace all ansi
generation in Cancan95 with the appropriate MS Console library calls to 
position the cursors etc. This is probably a weekends worth of hacking, more
than I can afford right now, if someone else wants, feel free!

Authors:
--------

Bjorn Wesen (bjorn@sparta.lu.se) (Win32 code),
Massimiliano Ghilardi (ghilardi@cibs.sns.it) (powwow 0.8),
Finn Arne Gangstad (finnag@pvv.unit.no),
David Gay (dgay@di.epfl.ch),
Gary Dezern (gdezern@satelnet.org),
Lai-Chang Woo (vivriel@scs.com.sg),
Mattias Engdegard (f91-men@nada.kth.se) (original cancan author)

Installation:
-------------

This port to Win32 was made by me (bjorn@sparta.lu.se). To install it
just put the cancan95.exe file in the same directory as the cancan.hlp
file.

You have to have a 32-bit Winsock (I think) like the one that is included
with win95. You also have to have a win32 system that supports multi-
threading like Win95 and WinNT - I doubt Win32S for Win3.11 works.

YOU HAVE TO RUN ANSI.SYS IN YOUR CONFIG.SYS FILE! Otherwise the screen
output won't recognize ansi-control codes and nothing will work (you will
get a lot of garbage characters, every time you press a button!). If
you are using win95, put this somewhere in c:\config.sys:

DEVICE=C:\WINDOWS\COMMAND\ANSI.SYS

If you didn't have this in the config.sys, insert it and reboot.

Again, NT4 won't recognize the ANSI codes that Cancan95 uses. This cannot
be fixed in the OS in any possible way I think, all attempts have failed 
because NT4 only supports ANSI.SYS when running old DOS programs and not
Win32 applications like this. 

If you haven't used cancan or powwow before, you start a session by:

cancan95 <filename>

where filename is an existing or non-existing file containing aliases,
marks, actions etc used for one host. If the file doesn't exist, cancan
will prompt you for a host and port number and then create the file
with default keybindings etc.

Keybindings in win95: to bind the numeric keypad, numlock has to be LIT.
To for example bind east to 6 on the keypad, do:
#bind kp6=east
Then it prompts you to push the key and you push the 6 and it's done.
You can do the same to all the function keys and keypad keys.

PageUp and PageDown accesses the scrollback. This feature is NOT 100% 
clean yet but at least its rudimentary. 

Actions MIGHT be bugged so that the line that triggers them is not 
printed on your screen.

Compiling:
----------

The full source and project setup files for Cancan95 are included in this zip
archive. It was compiled using VC++5.0, just doubleclick on the Cancan95.dsw
file and it'll start up in your compiled. In case you have any other compiler
and still want to contribute, please make sure that the VC++5 project files
are kept intact and that you don't add any compiler-specific stuff, if you
want me to merge the source you mail me in any sane fashion.


*Online editing (for MUME only):
*-------------------------------
*
*You first set the editor you want to use in an environment variable
*before you run cancan95:
*
*set CANCANEDITOR=&c:\windows\notepad.exe
*
*The & in the beginning tells cancan to spawn the editor asynchronously
*as a separate process in another window - that way you can keep mudding
*while editing. When you exit the editor the file is sent back.
*
*If you care, you can change the pager used for viewing texts as well:
*
*set CANCANPAGER=c:\windows\command\more.com
*
*is the default.
*
*Dont forget to 'cha edit mume' on mume, and #identify in cancan95.



If you find something that works but is bugged you can mail me about it
(bjorn@sparta.lu.se). If you find something that doesn't work at all,
like #time, don't bother to mail me because I already know.

You are very welcome to improve Cancan95. It's in the public domain so neither
me nor any of the other authors have any copyright on anything we've put in it, 
but if you want the new version you've just made distributed on a site where
people already know Cancan95 live, please mail me the new zip archive. Also please
read the todo.txt file in this directory!

Bjorn Wesen
bjorn@sparta.lu.se


 







