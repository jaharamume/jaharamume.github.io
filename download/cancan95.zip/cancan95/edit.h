/* public from edit.c */

typedef struct {
  char *name;
  void (*funct)();
} edit_function;

extern edit_function internal_functions[];

int lookup_edit_name();
int lookup_edit_function();

void prev_char();
void next_char();
void prev_line();
void next_line();
void key_run_command();
void enter_line();
void complete_word();
void complete_line();
void del_char_left();
void del_char_right();
void enter_into_history();
void clear_line();
void beginning_of_line();
void end_of_line();
void kill_to_eol();
void transpose_chars();
void insert_char();
void redraw_input_line();
void del_word_right();
void del_word_left();
void next_word();
void prev_word();
