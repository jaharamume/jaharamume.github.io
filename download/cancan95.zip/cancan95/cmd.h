/* public things from cmd.c */

typedef struct {
    char *name;		/* command name */
    char *help;		/* short help */
    void (*funct)();	/* function to call */
} cmdstruct;

extern cmdstruct commands[];

char *first_valid();
char *first_regular();
char *get_next_instr();
void escape_specials();
void unescape();
char *attr_name();
void attr_string();
int parse_attributes();
int attr_token();
void parse_alias();
void parse_action();
void parse_marker();
void add_anonymous_action();
void parse_bind_from_file();
char *seq_name();
int cmp_vtime();
void show_delaynode();
void show_stat();
