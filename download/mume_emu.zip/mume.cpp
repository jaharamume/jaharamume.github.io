#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string>

#define VERSION "0.37a"
#define UPDATED "30/05/02 16:04"

struct ZoneRoom
{
	string Name;
	string Description;
	string Sector;
	int North;
	int East;
	int South;
	int West;
	int Up;
	int Down;

	bool NorthDoorExists;
	string NorthDoorName;
	int NorthKey;
	bool EastDoorExists;
	string EastDoorName;
	int EastKey;
	bool SouthDoorExists;
	string SouthDoorName;
	int SouthKey;
	bool WestDoorExists;
	string WestDoorName;
	int WestKey;
	bool UpDoorExists;
	string UpDoorName;
	int UpKey;
	bool DownDoorExists;
	string DownDoorName;
	int DownKey;
};

string null;
int zone;
ZoneRoom Room[200];

void SetZone()
{
	for(int x = 0; x <= 199; x++)
	{
		Room[x].Name = "***FREE***";
		Room[x].Description = null;
		Room[x].Sector = null;
		Room[x].North = -1;
		Room[x].East = -1;
		Room[x].South = -1;
		Room[x].West = -1;
		Room[x].Up = -1;
		Room[x].Down = -1;

		Room[x].NorthDoorExists = false;
		Room[x].NorthDoorName = null;
		Room[x].NorthKey = -1;
		Room[x].EastDoorExists = false;
		Room[x].EastDoorName = null;
		Room[x].EastKey = -1;
		Room[x].SouthDoorExists = false;
		Room[x].SouthDoorName = null;
		Room[x].SouthKey = -1;
		Room[x].WestDoorExists = false;
		Room[x].WestDoorName = null;
		Room[x].WestKey = -1;
		Room[x].UpDoorExists = false;
		Room[x].UpDoorName = null;
		Room[x].UpKey = -1;
		Room[x].DownDoorExists = false;
		Room[x].DownDoorName = null;
		Room[x].DownKey = -1;
	}
}

void LoadFile(char *file)
{
	 string Line[1000];
	 int numlines = 0;
	 int numchars = 0;
	 char c;
     FILE *ptr;

     ptr = fopen(file,"r");
     while ((c = fgetc(ptr)) != EOF)
     {
		numchars++;
 		if(c == '\n')
		{
			numlines++;
		}
     }
     fclose(ptr);
     numlines--;      // Due to the last line, we don't want a blank string

	 cout << "Number of Lines: " << numlines << "\tFile: " << file << "\nNumber of Characters: " << numchars << "\n\n";

	 int LineNum = 0;
     ptr = fopen(file,"r");
     while ((c = fgetc(ptr)) != EOF)
     {
 		if(c == '\n')
		{
			LineNum++;
		}
		else
		{
			Line[LineNum] += c;
		}
     }
     fclose(ptr);

	 // Decryption
	 int x, length, find, tab, digits, totalrooms, totalname, totaldesc;
	 string type, data;

     totalname = 0;
     totaldesc = 0;

     for(LineNum = 0;LineNum <= numlines;LineNum++)
     {
		 length = Line[LineNum].length();
		 digits = 0;

		 for(find = 0; find <= length; find++)
		 {
			tab = Line[LineNum].find('\t');
			if(tab == string::npos) tab = 0;
		 }

   // Tab - 2 because the smallest command after the room # is Up
   		 for(find = 1; find <= tab - 2; find++)
		 {
               if(Line[LineNum].substr(find-1,find).find("0") != string::npos
               || Line[LineNum].substr(find-1,find).find("1") != string::npos
               || Line[LineNum].substr(find-1,find).find("2") != string::npos
               || Line[LineNum].substr(find-1,find).find("3") != string::npos
               || Line[LineNum].substr(find-1,find).find("4") != string::npos
               || Line[LineNum].substr(find-1,find).find("5") != string::npos
               || Line[LineNum].substr(find-1,find).find("6") != string::npos
               || Line[LineNum].substr(find-1,find).find("7") != string::npos
               || Line[LineNum].substr(find-1,find).find("8") != string::npos
               || Line[LineNum].substr(find-1,find).find("9") != string::npos)
               {
                 digits = find;
               }
               else find = tab;
//               cout << Line[LineNum].substr(0,find).c_str() << " (" << find << ", " << digits << ")\n";
//               system("pause");

		 }

/*		 for(find = 0; find <= tab; find++)
		 {
			 if(atoi(Line[LineNum].substr(digits,1).c_str()) != 0 || Line[LineNum].substr(digits,1).c_str() == "0")
			 {
				 digits++;
			 }
		 }
   */
		 if(totalrooms < atoi(Line[LineNum].substr(0,digits).c_str())) totalrooms = atoi(Line[LineNum].substr(0,digits).c_str());

         //cout << " D" << digits << "\n";

		 //digits = 2;
		 x = atoi(Line[LineNum].substr(0,digits).c_str());
         //x = atoi(Line[LineNum].substr(0,digits).c_str());
		 type = Line[LineNum].substr(digits,tab - digits).c_str();
		 data = Line[LineNum].substr(tab + 1, length).c_str();

		 if(Line[LineNum].substr(0,tab) == "ZoneNumber") zone = atoi(data.c_str());
	 
		 for(int RoomX = 0; RoomX <= numlines;RoomX++)
		 {
			 if(x == RoomX)
			 {
				 if(type == "Name")
                 {
                       Room[x].Name = data;
                       totalname++;
                 }
				 else if(type == "Description")
                 {
                       if(Room[x].Description == null) totaldesc++;
                       Room[x].Description += data + "\n";
                 }
				 else if(type == "Sector") Room[x].Sector = data;	
				 else if(type == "West") Room[x].West = atoi(data.c_str());	
				 else if(type == "East") Room[x].East = atoi(data.c_str());
				 else if(type == "North") Room[x].North = atoi(data.c_str());
				 else if(type == "South") Room[x].South = atoi(data.c_str());
				 else if(type == "Up") Room[x].Up = atoi(data.c_str());
				 else if(type == "Down") Room[x].Down = atoi(data.c_str());
				 else if(type == "NorthDoorExists" && data == "True") Room[x].NorthDoorExists = true;
				 else if(type == "NorthDoorName") Room[x].NorthDoorName = data;
				 else if(type == "NorthKey") Room[x].NorthKey = atoi(data.c_str());
				 else if(type == "EastDoorExists" && data == "True") Room[x].EastDoorExists = true;
				 else if(type == "EastDoorName") Room[x].EastDoorName = data;
				 else if(type == "EastKey") Room[x].EastKey = atoi(data.c_str());
				 else if(type == "SouthDoorExists" && data == "True") Room[x].SouthDoorExists = true;
				 else if(type == "SouthDoorName") Room[x].SouthDoorName = data;
				 else if(type == "SouthKey") Room[x].SouthKey = atoi(data.c_str());
				 else if(type == "WestDoorExists" && data == "True") Room[x].WestDoorExists = true;
				 else if(type == "WestDoorName") Room[x].WestDoorName = data;
				 else if(type == "WestKey")	Room[x].WestKey = atoi(data.c_str());
				 else if(type == "UpDoorExists" && data == "True") Room[x].UpDoorExists = true;
				 else if(type == "UpDoorName") Room[x].UpDoorName = data;
				 else if(type == "UpKey") Room[x].UpKey = atoi(data.c_str());
				 else if(type == "DownDoorExists" && data == "True") Room[x].DownDoorExists = true;
				 else if(type == "DownDoorName") Room[x].DownDoorName = data;
				 else if(type == "DownKey")	Room[x].DownKey = atoi(data.c_str());
				 else cout << "Unidentified: " << Line[LineNum].c_str() << "\t|Digits:" << digits << "  Tab:" << tab << "\n";
			 }
		 }
     }
     cout << "\n\nCompleted Decryption!\tFound " << totalname << " Room Names and " << totaldesc << " Room Descriptions!" << endl;
	 cout << "Waiting for User Intervention...\n\n";
     system("pause");
     cout << "Starting Emulation Engine...\n\n";
}

string CompleteWord(string input)
{
	int foundchars = 0;
 	char *options[] = {{"quit",},{"north",},{"east",},{"south",},
	{"west",},{"up",},{"down",},{"look",},{"exits",},{"examine",},{"info",},
	{"info",},{"score",},{"status",},{"/goto",},{"change"}};
	
	for(int option = 0; option <= 15; option++)
	{
		foundchars = 0;
		for(int charnum = 0; charnum <= input.length() - 1; charnum++)
		{
			if(input[charnum] == options[option][charnum])
			{
				foundchars++;
			}
			else
			{
				foundchars = 0;
				break;
			}
		}
		if(foundchars >= 1) return options[option];
	}
	return input;
}

void DisplayExits(int zone, int x)
{
	 cout << "Obvious exits (room: [" << zone << ":" << x << "]):" << endl;
	 if(Room[x].North != -1)
	 {
		 cout << "North - ";
		 if(Room[x].NorthDoorExists == true) cout << "A closed '" << Room[x].NorthDoorName.c_str() << "'  [" << zone << ":" << Room[x].North << "]" << endl;
		 else cout << Room[Room[x].North].Name.c_str() << "  [" << zone << ":" << Room[x].North << "]" << endl;
	 }
	 if(Room[x].East != -1)
	 {
		 cout << "East  - ";
		 if(Room[x].EastDoorExists == true) cout << "A closed '" << Room[x].EastDoorName.c_str() << "'  [" << zone << ":" << Room[x].East << "]" << endl;
		 else cout << Room[Room[x].East].Name.c_str() << "  [" << zone << ":" << Room[x].East << "]" << endl;
	 }
	 if(Room[x].South != -1)
	 {
		 cout << "South - ";
		 if(Room[x].SouthDoorExists == true) cout << "A closed '" << Room[x].SouthDoorName.c_str() << "'  [" << zone << ":" << Room[x].South << "]" << endl;
		 else cout << Room[Room[x].South].Name.c_str() << "  [" << zone << ":" << Room[x].South << "]" << endl;
	 }
	 if(Room[x].West != -1)
	 {
		 cout << "West  - ";
		 if(Room[x].WestDoorExists == true) cout << "A closed '" << Room[x].WestDoorName.c_str() << "'  [" << zone << ":" << Room[x].West << "]" << endl;
		 else cout << Room[Room[x].West].Name.c_str() << "  [" << zone << ":" << Room[x].West << "]" << endl;
	 }
	 if(Room[x].Up != -1)
	 {
		 cout << "Up    - ";
		 if(Room[x].UpDoorExists == true) cout << "A closed '" << Room[x].UpDoorName.c_str() << "'  [" << zone << ":" << Room[x].Up << "]" << endl;
		 else cout << Room[Room[x].Up].Name.c_str() << "  [" << zone << ":" << Room[x].Up << "]" << endl;
	 }
	 if(Room[x].Down != -1)
	 {
		 cout << "Down  - ";
		 if(Room[x].DownDoorExists == true) cout << "A closed '" << Room[x].DownDoorName.c_str() << "'  [" << zone << ":" << Room[x].Down << "]" << endl;
		 else cout << Room[Room[x].Down].Name.c_str() << "  [" << zone << ":" << Room[x].Down << "]" << endl;
	 }
}

void DisplayRoom(int zone, int x)
{
	 cout << Room[x].Name.c_str() << endl
	  	  << Room[x].Description.c_str();
	 DisplayExits(zone, x);

}

void main()
{
	 cout << "### MumeBuilder Emulator, written by Jahara" << endl
		  << "### Last Update " << UPDATED << "\n### Version " << VERSION << "\n\nStarting Program..." << endl;

	 SetZone();
     LoadFile("zone.txt");

	 cout << "\n---------------------MUME BUILDER EMULATOR--------------------" << endl
		  << "- Entering World!   |  \"quit\" ends Simulation  | Ver:  " << VERSION << " -" << endl
          << "--------------------------------------------------------------\n" << endl;

	 // Emulation Zone
	 int x = 0;
	 char key;
	 string rawinput, input, oldinput, arguments, oldarguments;
	 int find;
	 bool quitnow = false;
	 bool display = false;
	 
	 DisplayRoom(zone, x);

	 do
	 {
		 // Prompt
		 cout << endl << "o " << zone << x << "[" << zone << ":" << x << "]>" << endl;

		 // Key Input
		 do
		 {
			key = getchar();
			if(key != '\n') rawinput += key;

		 }
		 while(key != '\n');

		 // Argument Seperation & Word Completion
		 find = rawinput.find(' ');
		 if(find != string::npos)
		 {
			 arguments = rawinput.substr(find, rawinput.length());
			 rawinput.resize(find);
		 }
		 input = CompleteWord(rawinput);
		 
			 // What to do
		 if(input == "quit")
		 {
			quitnow = true;
		 }
         else if(input == "load")
         {
                    SetZone();
                    LoadFile("zone.txt");
                    display = true;
         }
		 else if(input == "look" || input == "examine")
		 {
			display = true;
		 }
		 else if(input == "exits")
		 {
			DisplayExits(zone, x);
		 }
		 else if(input == "score" || input == "status" || input == "who" || input == "where")
		 { 
			 cout << "Thanks for the compliment on my program...\n However, this is only an emulator ;)" << endl;
		 }
		 else if(input == "/goto")
		 { 
			 find = arguments.find(':');
			 if(find != string::npos) find = 0;

			 x = atoi(arguments.substr(find + 1, arguments.length() - find - 1).c_str());
			 display = true;
		 }
		 else if(input == "change")
		 { 
			 cout << "Change what? I can't change yet!" << endl;
		 }
		 else if(input == "info" || input == "help")
		 { 
        	 cout << "### MumeBuilder Emulator, written by Jahara (jahara@i12.com)" << endl
          		  << "### Last Update " << UPDATED << "\n### Version " << VERSION << endl;
			 cout << "rawinput:     " << rawinput.c_str() << endl
				  << "input:        " << input.c_str() << endl
				  << "arguments:    " << arguments.c_str() << endl
				  << "oldinput:     " << oldinput.c_str() << endl
				  << "oldarguments: " << oldarguments.c_str() << endl
				  << "Room[z:x]:    " << "[" << zone << ":" << x << "]" << endl;
		 }

		 else if(input == "north" || input == "east" || input == "south" || input == "west" || input == "up" || input == "down")
		 {	
			 if(Room[x].North != -1 && input == "north")
			 {	
				 x = Room[x].North;
				display = true;
			 }
    		 else if(Room[x].East != -1 && input == "east")
			 {	
				 x = Room[x].East;
				display = true;
			 }
			 else if(Room[x].South != -1 && input == "south")
			 {	
				 x = Room[x].South;
				display = true;
			 }
			 else if(Room[x].West != -1 && input == "west")
			 {	
				 x = Room[x].West;
				display = true;
			 }
			 else if(Room[x].Up != -1 && input == "up")
			 {	
				 x = Room[x].Up;
				display = true;
			 }
			 else if(Room[x].Down != -1 && input == "down")
			 {	
				 x = Room[x].Down;
				display = true;
			 }
			 else cout << "Alas, you cannot go that way..." << endl;
		 }
		 else
		 {
			cout << "Arglebargle, glop-glyf!?!" << endl;
			display = false;
		 }

	     if(display) DisplayRoom(zone, x);
		 display = false;
		 oldinput = input;
		 oldarguments = arguments;
		 rawinput = null;
		 arguments = null;
	 }
	 while(!quitnow);
}
